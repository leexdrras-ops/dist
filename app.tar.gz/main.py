import time
import threading
import flet as ft
import requests
import urllib3
# 💡 引入 Flet 專用的手機真實定位套件
import flet_geolocator as fg

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

SERVER_URL = "https://my-traffic-brain.onrender.com/check_safety"

def main(page: ft.Page):
    page.title = "🛡️ 真．GPS 雲端自動防禦雷達"
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    
    # 💡 建立定位元件並加到頁面中（手機開機必備）
    geolocator = fg.FletGeolocator()
    page.overlay.append(geolocator)
    
    # UI 顯示元件
    title_text = ft.Text("🛰️ GPS 雲端實時防禦雷達", size=22, weight=ft.FontWeight.BOLD, color="blue")
    gps_status = ft.Text("📍 正在獲取手機 GPS 定位...", size=16, color="orange")
    danger_alert_box = ft.Text("🟡 雲端通道建立中...", size=18, weight=ft.FontWeight.BOLD, color="green")

    page.add(
        title_text,
        ft.Container(height=30),
        gps_status,
        ft.Container(height=40),
        ft.Text("⚡ 雷達背景監聽狀態:", size=14, color="grey"),
        danger_alert_box,
    )
    page.update()

    def background_radar():
        # 先等待手機硬體與 Flet 完全對齊
        time.sleep(2)
        
        while True:
            try:
                # 🚀 核心關鍵：直接向手機硬體索取當前最新的真實 GPS 座標
                pos = geolocator.get_current_position()
                
                if pos:
                    lat = pos.latitude
                    lng = pos.longitude
                    
                    # 更新畫面上的真實定位文字
                    gps_status.value = f"📍 目前真實定位:\n緯度: {lat:.5f}\n經度: {lng:.5f}"
                    
                    # 把熱騰騰的真實經緯度噴向 Render 雲端
                    url = f"{SERVER_URL}?lat={lat}&lng={lng}"
                    response = requests.get(url, verify=False, timeout=5)

                    if response.status_code == 200:
                        data = response.json()
                        if data["is_dangerous"]:
                            danger_alert_box.value = f"🚨 警報：附近歷史車禍達 {data['accident_count']} 次！"
                            danger_alert_box.color = "red"
                        else:
                            danger_alert_box.value = f"🟢 辨識結果：此區安全\n(歷史車禍: {data['accident_count']} 次)"
                            danger_alert_box.color = "green"
                    else:
                        danger_alert_box.value = "🟡 雲端大腦回應異常..."
                        danger_alert_box.color = "orange"
                else:
                    gps_status.value = "❌ 暫時抓不到 GPS，請檢查手機定位開關是否開啟"
                    
            except Exception as e:
                danger_alert_box.value = "⏳ 正在與雲端同步定位通道..."
                danger_alert_box.color = "orange"
            
            # 強制刷新手機 UI 畫面
            try:
                page.update()
            except:
                break
                
            time.sleep(3)

    # 啟動背景雷達監聽
    t = threading.Thread(target=background_radar, daemon=True)
    t.start()

if __name__ == "__main__":
    ft.run(main)